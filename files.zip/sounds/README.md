# Sound Effects Credits

All sound effects are from Pixabay and are free for commercial use.

## Files and Sources

1. cheer.mp3
- Source: https://pixabay.com/sound-effects/crowd-cheer-ii-6263/
- Duration: 2 seconds
- Usage: Plays when answering correctly

2. whistle.mp3
- Source: https://pixabay.com/sound-effects/referee-whistle-blow-gymnasium-6320/
- Duration: 1 second
- Usage: Plays for incorrect answers or penalties

3. touchdown.mp3
- Source: https://pixabay.com/sound-effects/stadium-crowd-loud-cheer-a-6280/
- Duration: 3 seconds
- Usage: Plays when scoring a touchdown

4. victory.mp3
- Source: https://pixabay.com/sound-effects/success-fanfare-trumpets-6185/
- Duration: 2 seconds
- Usage: Plays when winning the game

5. first-down.mp3
- Source: https://pixabay.com/sound-effects/male-voice-first-down-6314/
- Duration: 1 second
- Usage: Plays when getting a first down

## Implementation

1. Download each sound effect from the provided URLs
2. Convert to MP3 format if needed (use a tool like online-audio-converter.com)
3. Place all files in this directory
4. Files should be named exactly as listed above